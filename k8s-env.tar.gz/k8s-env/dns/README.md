Folked from https://github.com/kubernetes/kubernetes/tree/master/cluster/addons/dns (commit 71b96422)
Modified a lot