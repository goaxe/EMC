Forked from https://github.com/kubernetes/heapster/tree/master/deploy/kube-config/influxdb (commit 5e6f0dc5eb)
Modified a lot
