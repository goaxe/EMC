#!/bin/bash

################################
# This requester will send requests to web app pressurer to simulate workload,
# and log what it gets
################################

BASH=/bin/bash

count=0

abs() {
    if [ $1 -lt 0 ]; then
        echo $(expr 0 - $1)
    else
        echo $1
    fi
}

request_count() {
    minute_in_hour=$(date +"%M")
    request_count=$(expr $minute_in_hour - 30)
    request_count=$(abs $request_count)
    request_count=$(expr $request_count / 5 + 1)
    echo $request_count
}

execute() {
    my_id=$count
    echo "[$(date -u)]" "execution id=$my_id started ..."
    results=$(curl -X GET 'http://10.62.98.250:31644/?cpu_loop=1000&db_read=10&db_update=10&db_append=1' 2>/dev/null)
    results=$(echo $results | sed -e "s/<br *\/>/\n/g")
    echo "[$(date -u)]" "execution id=$my_id finished:" \
        $(echo "$results" | grep -i 'Session ID'), \
        $(echo "$results" | grep -i TIME_ELAPSED), \
        $(echo "$results" | grep -i 'cache hits'), \
        $(echo "$results" | grep -i 'update error count'), \
        $(echo "$results" | grep -i 'append error count'), \
        $(echo "$results" | grep -i 'warn'), \
        $(echo "$results" | grep -i 'fatal')
}

while true; do
    concurrent=$(request_count)
    for i in $(seq 1 $concurrent); do
        count=$(expr $count + 1)
        execute &
    done
    sleep 5
done

