#!/bin/bash
set -x

rm -rf /mnt/influxdb/*
mkdir -p /mnt/influxdb