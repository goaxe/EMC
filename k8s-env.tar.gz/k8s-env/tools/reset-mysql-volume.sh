#!/bin/bash
set -x

rm -rf /mnt/mysql/*
umount /mnt/mysql
rm -rf /data/mysql/*

mkdir -p /data/mysql
cd /data/mysql
dd if=/dev/zero of=disk1.img bs=1 count=1 seek=1G

mkdir /mnt/mysql
losetup /dev/loop10 disk1.img
mkfs.ext4 /dev/loop10
mount /dev/loop10 /mnt/mysql

