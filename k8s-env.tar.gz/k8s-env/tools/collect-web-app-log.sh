#!/bin/bash

#####################################
# This script is used to copy web app logs to our experiment results folder
# You need to run it on each kubelet host
#####################################

experiment_date=20150923    # need to modify
pod_name="$( docker ps | grep pressurer\: | cut -d '_' -f 3 )"
container_id="$( docker ps |grep pressurer\: | awk {'print $1'} )"

docker cp ${container_id}:/var/log/apache2/access.log ~/${pod_name}/
docker cp ${container_id}:/var/log/apache2/error.log ~/${pod_name}/
ssh 10.62.98.243 "mkdir -p /data/experiments/${experiment_date}/${pod_name}"
scp ~/${pod_name}/* 10.62.98.243:/data/experiments/${experiment_date}/${pod_name}/
rm -rf ~/${pod_name}/