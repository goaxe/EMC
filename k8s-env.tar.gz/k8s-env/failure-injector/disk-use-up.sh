#!/bin/bash

inject() {
    fallocate -l 1G /mnt/mysql/large-file.img
}

recover() {
	rm -f /mnt/mysql/large-file.img
}

usage () {
	echo "argument: inject | recover"
}

case "$1" in
    inject) inject ;;
    recover) recover ;;
    *) usage ;;
esac
