#!/bin/bash

inject() {
    chmod -R a-rwx /mnt/mysql	
}

recover() {
	chmod -R a+rwx /mnt/mysql
}

usage () {
	echo "argument: inject | recover"
}

case "$1" in
    inject) inject ;;
    recover) recover ;;
    *) usage ;;
esac
