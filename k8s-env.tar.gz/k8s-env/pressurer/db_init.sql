CREATE SCHEMA pressurer;
USE pressurer;
CREATE TABLE `pressurer`.`messages` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `message` TEXT NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `id_UNIQUE` (`id` ASC)
);
