<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

set_include_path(get_include_path() . PATH_SEPARATOR . '/usr/local/lib/php');

require 'Predis/Autoloader.php';

Predis\Autoloader::register();

$session_id = uniqid();
echo "Session ID: $session_id". '<br />';

$time_start = microtime(true);
$cpu_loop = 0;
$db_read = 0;
$db_append = 0;
$db_update = 0;

if (isset($_GET['cpu_loop']) === true) {
    $cpu_loop = $_GET['cpu_loop'];
}
if (isset($_GET['db_read']) === true) {
    $db_read = $_GET['db_read'];
}
if (isset($_GET['db_append']) === true) {
    $db_append = $_GET['db_append'];
}
if (isset($_GET['db_update']) === true) {
    $db_update = $_GET['db_update'];
}

function rand_str($length = 10) {
    $chars = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ ';
    $chars_len = strlen($chars);
    $str = '';
    for ($i = 0; $i < $length; $i++) {
        $str .= $chars[rand(0, $chars_len - 1)];
    }
    return $str;
}

# Log entry time
error_log("Session {$session_id} entry time {$time_start}");

# Get my ip address
$my_ip = $_SERVER['SERVER_ADDR'];
echo "SERVER IP: {$my_ip}" . '<br />';

# Create db connection
echo '<br />';
$db_host_env_var = getenv('DB_HOST_ENV_VAR');
$db_port_env_var = getenv('DB_PORT_ENV_VAR');
echo "DB_HOST_ENV_VAR: {$db_host_env_var}, DB_PORT_ENV_VAR: {$db_port_env_var}" . '<br />';
$db_host = getenv($db_host_env_var);
$db_port = getenv($db_port_env_var);
echo "DB_HOST FROM ENV: {$db_host}, DB_PORT FROM ENV: {$db_port}" . '<br />';
if (empty($db_host) || empty($db_port)) {
    $db_host = '10.62.98.253';
    $db_port = '31407';
}
echo "DB_HOST: {$db_host}, DB_PORT: {$db_port}" . '<br />';
$conn = new mysqli($db_host, 'root', 'dangerous', 'pressurer', $db_port);

# Get redis connection
echo '<br />';
$redis_hosts = array();
$redis_ports = array();
$redis_hosts_env_var = getenv('REDIS_HOSTS_ENV_VAR');
$redis_ports_env_var = getenv('REDIS_PORTS_ENV_VAR');
echo "REDIS_HOSTS_ENV_VAR: {$redis_hosts_env_var}, REDIS_PORTS_ENV_VAR: {$redis_ports_env_var}" . '<br />';

foreach (explode(',', $redis_hosts_env_var) as $redis_host_env_var) {
    $redis_host_env_var = trim($redis_host_env_var);
    if (!empty($redis_host_env_var)
        && !empty(getenv($redis_host_env_var))) {
        $redis_hosts []= getenv($redis_host_env_var);   
    }
}
if (empty($redis_hosts)) {
    $redis_hosts []= '10.62.98.253';
}
foreach (explode(',', $redis_ports_env_var) as $redis_port_env_var) {
    $redis_host_port_var = trim($redis_port_env_var);
    if (!empty($redis_port_env_var)
        && !empty(getenv($redis_port_env_var))) {
        $redis_ports []= getenv($redis_port_env_var);   
    }
}
if (empty($redis_ports)) {
    $redis_ports []= '32747';
}
echo "REDIS_HOSTS: " . print_r($redis_hosts, true) . '<br />';
echo "REDIS_PORTS: " . print_r($redis_ports, true) . '<br />';
if (count($redis_hosts) != count($redis_ports)) {
    exit("Redis hosts and ports environment variable counts are not matched.");
}

$redis_uris = array();
for ($i = 0; $i < count($redis_hosts); $i++) {
    $redis_uris []= "tcp://{$redis_hosts[$i]}:{$redis_ports[$i]}";
}

echo "REDIS_URIS: " . print_r($redis_uris, true) . '<br />';
$redis = new Predis\Client($redis_uris);
echo '<br />';

# CPU loop
for ($i = 0; $i < $cpu_loop; $i++) {
    for ($c = 0; $c < 1000; $c++) {
        ;
    }
}

# DB read
echo "DB reads ..." . '<br />';
$redis_hits = 0;
for ($i = 0; $i < $db_read; $i++) {
    $results = $conn->query("SELECT id FROM messages ORDER BY RAND() LIMIT 1");
    if ($row = $results->fetch_assoc()) {
        $which_id = intval($row['id']);
    } else {
        echo "DB reads: cannot select a random row.". '<br />';;
        break;
    }

    $message = $redis->get($which_id);
    if (is_null($message)) {
        $results = $conn->query("SELECT message FROM messages WHERE id = {$which_id}");
        if ($row = $results->fetch_assoc()) {
            $message = $row['message'];
            $redis->set($which_id, $message);
            $redis->expire($which_id, 300);
        }
    } else {
        $redis->expire($which_id, 300);
        $redis_hits++;
    }
    if (rand(0, $db_read) < 20) {
        echo $which_id . "\t\t" . substr($message, 0, min(strlen($message), 64)) . '<br />';
    }
}
echo "Redis cache hits: {$redis_hits}" . '<br />';
echo '<br />';

# DB update
echo "DB updates ..." . '<br />';
$error_count = 0;
for ($i = 0; $i < $db_update; $i++) {
    $results = $conn->query("SELECT id FROM messages ORDER BY RAND() LIMIT 1");
    if ($row = $results->fetch_assoc()) {
        $which_id = intval($row['id']);
    } else {
        echo "DB update: cannot select a random row.";
        break;
    }

    $message = rand_str(256);
    $redis->set($which_id, $message);
    $redis->expire($which_id, 300);

    $results = $conn->query("UPDATE messages SET message='{$message}' WHERE id={$which_id}");
    var_dump($results);
    if (!$results) {
        $error_count++;
    }
    if (rand(0, $db_update) < 20) {
        echo $which_id . "\t\t" . substr($message, 0, min(strlen($message), 64)) . '<br />';
    }
}
echo "DB update error count: {$error_count}". '<br />';;
if ($error_count > 0) {
    error_log("DB update error count: {$error_count}");
}
echo '<br />';

# DB append
echo "DB appends ..." . '<br />';
$error_count = 0;
for ($i = 0; $i < $db_append; $i++) {
    $message = rand_str(256);
    $sql = "INSERT INTO messages (message) VALUES ('{$message}')";
    
    $results = $conn->query($sql);
    var_dump($results);
    if (!$results) {
        $error_count++;
    }
    $which_id = $conn->insert_id;
    if (rand(0, $db_append) < 20) {
        echo $which_id . "\t\t" . substr($message, 0, min(strlen($message), 64)) . '<br />';
    }
}
echo "DB append error count: {$error_count}". '<br />';;
if ($error_count > 0) {
    error_log("DB append error count: {$error_count}");
}
echo '<br />';

$time_end = microtime(true);

# Log finish time
error_log("Session {$session_id} finish time {$time_end}");
?>

CPU_LOOP: <?php echo $cpu_loop; ?> <br />
DB_READ: <?php echo $db_read; ?> <br />
DB_UPDATE: <?php echo $db_update; ?> <br />
DB_APPEND: <?php echo $db_append; ?> <br />
TIME_ELAPSED (sec): <?php echo ($time_end - $time_start); ?> <br />

