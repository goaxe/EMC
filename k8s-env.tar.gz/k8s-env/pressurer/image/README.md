Modified based on https://github.com/tutumcloud/apache-php

The corp firewall prevent me front downloading php Predis lib. So I have to do it manually and put it into the image folder.
