kubectl delete service pressurer
kubectl delete rc pressurer