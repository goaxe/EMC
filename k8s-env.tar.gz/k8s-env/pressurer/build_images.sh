#!/bin/bash
set -x
set -e

VERSION='0.21'

cd image
docker build -t 10.62.98.243:5000/pressurer:${VERSION} .
docker push 10.62.98.243:5000/pressurer:${VERSION}