Folked from https://github.com/CaptTofu/mysql_replication_kubernetes/tree/master/galera_sync_replication (commit 3facae10c7)
Modified a lot.
