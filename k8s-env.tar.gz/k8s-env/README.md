
TODO write more info, e.g. cluster setup, multinode, etc


## Install Heapster + InfluxDB + Grafana

We use Heapster to monitor, InfluxDB to hold metrics, Grafana for visualization. Heapster requires DNS service.

### Enable DNS

To enable dns, change `/etc/kubernetes/kubelet` on each node, add below to `KUBELET_ARGS`, then restart

```
KUBELET_ARGS="--cluster_dns=10.254.0.10 --cluster_domain=cluster.local"
```

launch dns pods and services

```
cd dns
kubectl create -f skydns-rc.yaml
kubectl create -f skydns-svc.yaml
```

To test dns working, first, launch the busybox

```
cd dns
kubectl create -f busybox.yaml
```

Next, send dns requests from insdie the busybox container

```
$ kubectl exec busybox -- nslookup kubernetes
Server:    10.254.0.10
Address 1: 10.254.0.10

Name:      kubernetes
Address 1: 10.254.0.1

$ kubectl exec busybox -- nslookup kubernetes.default.svc.cluster.local
Server:    10.254.0.10
Address 1: 10.254.0.10

Name:      kubernetes.default.svc.cluster.local
Address 1: 10.254.0.1
```

### Enable Heapster + InfluxDB + Grafana

## Run a Simulation

A simulation runs for several hours, in which the web app (pressurer) transfers from health to failing to health to failing ... Heapster and various scripts collects necessary data as the experiment results.

Before you start, remove previous existing testees: all pressurer, redis, and mysql pod/rc/service. Stop the client requestor, failure injector, and diskio metrics collector.



