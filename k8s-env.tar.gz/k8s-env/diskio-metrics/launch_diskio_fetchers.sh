#!/bin/bash

set -x

nohup ./fetch-diskio-to-influxdb.sh 10.62.98.250 pressurer 2>&1 >> ./fetch-diskio-to-influxdb.sh.log &
nohup ./fetch-diskio-to-influxdb.sh 10.62.98.244 pressurer 2>&1 >> ./fetch-diskio-to-influxdb.sh.log &
nohup ./fetch-diskio-to-influxdb.sh 10.62.98.253 pressurer 2>&1 >> ./fetch-diskio-to-influxdb.sh.log &

# only need to fetch from the primary mysql
nohup ./fetch-diskio-to-influxdb.sh 10.62.98.250 pxc-node 2>&1 >> ./fetch-diskio-to-influxdb.sh.log &
