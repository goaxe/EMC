#!/bin/bash

#########################################################################
# This script pulls diskio metrics from kublet nodes and pushes to influxdb
#########################################################################

KUBELET_HOST=${1:-10.62.98.250}
STATS_PORT=10255
TARGET=${2:-pxc-node}    # or 'pressurer'

CONTAINER_NAME=$(ssh ${KUBELET_HOST} "docker ps | grep k8s_${TARGET} | awk -F '  +' '{print \$6}' | cut -d '_' -f 2 | cut -d '.' -f 1")
POD_ID=$(ssh ${KUBELET_HOST} "docker ps | grep k8s_${TARGET} | awk -F '  +' '{print \$6}' | cut -d '_' -f 5")
POD_NAME=$(ssh ${KUBELET_HOST} "docker ps | grep k8s_${TARGET} | awk -F '  +' '{print \$6}' | cut -d '_' -f 3")
QUERY_URL="http://${KUBELET_HOST}:${STATS_PORT}/stats/default/${POD_NAME}/${POD_ID}/${CONTAINER_NAME}"

raw_stats_to_influx_diskio() {
    python - <<EOT
import sys, json
obj = json.loads('$1')
ret = []
for entry in obj['stats'][-1]['diskio']['io_service_bytes']:
    ret.append({
        "name": "disk/read_bytes_cumulative",
        "columns": ["value", "hostname", "pod_id", "pod_name", "container_name", "major", "minor"],
        "points": [
            [entry['stats']['Read'], "$KUBELET_HOST", "$POD_ID", "$POD_NAME", "$CONTAINER_NAME", str(entry['major']), str(entry['minor'])]
        ]
    })
    ret.append({
        "name": "disk/write_bytes_cumulative",
        "columns": ["value", "hostname", "pod_id", "pod_name", "container_name", "major", "minor"],
        "points": [
            [entry['stats']['Write'], "$KUBELET_HOST", "$POD_ID", "$POD_NAME", "$CONTAINER_NAME", str(entry['major']), str(entry['minor'])]
        ]
    })
print json.dumps(ret, indent=4)
EOT
}

count=0
while true; do
    start_time=$(date +%s)

    RAW=$(curl -X GET ${QUERY_URL} 2>/dev/null)
    DATA=$(raw_stats_to_influx_diskio $RAW)
    curl -X POST 'http://10.62.98.250:32135/db/k8s/series?u=root&p=root' -d "$DATA" 2>/dev/null

    count=$(expr $count + 1)
    end_time=$(date +%s)
    used_time=$(expr $end_time - $start_time)
    echo "[$(date -u)]" "Metrics get: kubelet ${KUBELET_HOST}, pod name: ${POD_NAME}, container name: ${CONTAINER_NAME}"
    sleep $(expr 10 - $used_time)
done

